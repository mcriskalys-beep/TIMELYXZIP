
# Timelyx Project

Ce projet contient le code de base pour le déploiement du projet Timelyx sur GitHub et Netlify.

## Instructions de déploiement

1. Récupérez le dépôt sur votre machine avec la commande :
    ```bash
    git clone https://github.com/mcriskalys-beep/timelyx-project.git
    ```
2. Exécutez le script `deploy.sh` pour initialiser et pousser le projet vers GitHub :
    ```bash
    ./deploy.sh
    ```
