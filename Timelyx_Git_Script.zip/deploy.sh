
#!/bin/bash

# 1. Naviguer dans le dossier de ton projet
cd /chemin/vers/ton/dossier

# 2. Initialiser le dépôt Git (si ce n'est pas déjà fait)
git init

# 3. Ajouter tous les fichiers à Git
git add .

# 4. Créer un commit initial
git commit -m "Initial commit – ajout du projet Timelyx / MCRISCKALYS"

# 5. Lier ton dépôt local à GitHub (remplace avec ton URL de dépôt GitHub)
git remote add origin https://github.com/mcriskalys-beep/timelyx-project.git

# 6. Renommer la branche principale en 'main'
git branch -M main

# 7. Pousser le code vers GitHub (branche 'main')
git push -u origin main
